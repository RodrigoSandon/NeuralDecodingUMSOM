#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 22:05:03 2021

@author: rodrigosandon
"""
import os

parent_dir = "/Volumes/Passport/ResearchDataChen/Code/Data/allBrainRegionsnorm/"

class DataUtilities:
    
    def __init__(self, file_path):
        self.file_path = self
        
    def deleteFilesStartingWith(meta_folder_path, string):
        for folder in os.listdir(meta_folder_path):
            for csv in os.listdir(meta_folder_path + folder):
                if csv.startswith(string):
                    os.remove(meta_folder_path + folder + "/" + csv)
                    
                    

DataUtilities.deleteFilesStartingWith(parent_dir, "noisy")